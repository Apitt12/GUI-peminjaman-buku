# Aplikasi GUI Peminjaman Buku

Aplikasi ini dibuat menggunakan Python `tkinter` sebagai GUI dan `sqlite3` sebagai database.

## Fitur
- Menyimpan data peminjaman buku
- Melihat data peminjaman
- Menghapus data berdasarkan ID

## Cara Menjalankan
1. Pastikan Python sudah terinstall
2. Jalankan file `main.py` menggunakan perintah:
   ```
   python main.py
   ```

## Struktur Database
Database `peminjaman.db` akan otomatis dibuat saat program pertama kali dijalankan.

Tabel `peminjaman` berisi:
- id (INTEGER)
- nama (TEXT)
- judul_buku (TEXT)
- tanggal_pinjam (TEXT)
- tanggal_kembali (TEXT)

## Screenshot
![Tampilan GUI](screenshot.png)

---

Created by: Hafizd Azkiya
